ID Livro:{{$edicoes->id_livro}}<br>
Nome:{{$edicoes->titulo}}<br>
Data:{{$edicoes->data}}<br>
Observacoes:{{$edicoes->observacoes}}