<ul>
@foreach($edicoes as $edicao)
<li>{{$edicao->id_editora}}</li>
@endforeach
</ul>
{{$edicoes->render()}}