ID:{{$generos->idg}}<br>
Designacao:{{$generos->designacao}}<br>
Observacoes:{{$generos->observacoes}}